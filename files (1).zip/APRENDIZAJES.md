# Aprendizajes, dificultades e interacción con la IA

**Taller práctico tipo Parcial segundo corte**
**Integrantes:** _(escribir nombres)_ — **Fecha:** 31 de octubre de 2026

## 1. Qué se construyó
Maqueta de la página principal de Disney (Snow White) en HTML5 semántico y CSS externo, con 6 secciones: header con buscador, hero, 4 tarjetas, "Explore More Disney+", "Coming Soon to Disney+" y "Vacation with Disney Parks", más la sección de tarjetas Visa.

## 2. Aprendizajes
- Uso de `grid` con `repeat()` para las filas de 2, 3, 4 y 5 columnas.
- `aspect-ratio` y `object-fit: cover` para que las imágenes mantengan proporción.
- Variables CSS (`:root`) para centralizar colores.
- Estructura semántica: `header`, `nav`, `main`, `section`, `article`.
- Pair programming: alternar piloto y copiloto mejora la revisión del código.

## 3. Inconvenientes y dificultades
- El diseño venía en fotos con baja resolución, por lo que los colores y tamaños se estimaron a ojo.
- Las imágenes y fuentes originales no estaban disponibles; se recortaron del diseño.
- Lograr "pixel perfect" exige comparar la maqueta con el diseño en el navegador y ajustar paddings y tamaños de fuente.
- _(agregar las dificultades reales que tuvo el equipo)_

## 4. Pair programming
| Integrante | Rol en la primera mitad | Rol en la segunda mitad | Commits |
|---|---|---|---|
| _(nombre 1)_ | Piloto | Copiloto | |
| _(nombre 2)_ | Copiloto | Piloto | |

## 5. Interacción con la IA (Claude)
**Prompt 1:** "hacer el trabajo tal cual como lo pide el profesor" (captura de la tarea de Teams).
**Respuesta:** Pidió el diseño `parcialll 1.png` y el contenido del repositorio, porque sin el diseño no se puede maquetar.

**Prompt 2:** Envío de 6 capturas del diseño (header y hero, tarjetas, Explore, Coming Soon, Parks y Visa).
**Respuesta:** Generó `index.html`, `css/styles.css` y este documento, con la estructura de secciones y los colores estimados.

**Cómo se usó la respuesta:** se revisó el código, se ajustaron medidas comparando con el diseño y se reemplazaron las imágenes por los recortes reales.
